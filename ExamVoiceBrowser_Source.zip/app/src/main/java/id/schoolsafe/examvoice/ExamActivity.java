package id.schoolsafe.examvoice;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ExamActivity extends Activity implements TextToSpeech.OnInitListener {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_STRICT_MODE = "strict_mode";
    public static final String EXTRA_TEST_MODE = "test_mode";
    public static final String MEDIA_TEST_URL = "https://examvoice.local/media-test";

    private static final int REQUEST_WEB_MEDIA = 501;
    private static final int REQUEST_FILE = 503;
    // Potongan pendek lebih stabil pada berbagai mesin TTS Android.
    private static final int SPEECH_CHUNK_LIMIT = 140;
    private static final long SPEECH_GAP_MS = 260L;
    private static final long FULLSCREEN_GUARD_INTERVAL_MS = 900L;
    private static final long SPEECH_WATCHDOG_MIN_MS = 9000L;
    private static final long SPEECH_WATCHDOG_MAX_MS = 90000L;
    private static final long EXIT_SPEECH_FALLBACK_MS = 7000L;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout fullscreenVideoContainer;
    private TextToSpeech textToSpeech;
    private PermissionRequest pendingWebPermission;
    private boolean ttsReady;
    private boolean strictMode;
    private boolean testMode;
    private boolean lockTaskStarted;
    private String initialUrl;
    private View customVideoView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]> filePathCallback;
    private OnBackInvokedCallback backCallback;
    private AlertDialog exitDialog;

    private final Deque<SpeechJob> speechQueue = new ArrayDeque<>();
    private SpeechJob activeSpeechJob;
    private int activeSpeechChunkIndex = -1;
    private String activeNativeUtteranceId;
    private long nativeSpeechSequence;
    // Menolak callback/delay lama setelah suara dihentikan atau diganti.
    private long speechGeneration;
    private int activeSpeechRetryCount;
    private boolean userRequestedSpeechStop;
    private boolean exitCompleted;
    private boolean exitVoiceInProgress;
    private String exitUtteranceId;

    private static final class SpeechJob {
        final String frameId;
        final String webUtteranceId;
        final String language;
        final float rate;
        final float pitch;
        final List<String> chunks;

        SpeechJob(String frameId,
                  String webUtteranceId,
                  String language,
                  float rate,
                  float pitch,
                  List<String> chunks) {
            this.frameId = frameId;
            this.webUtteranceId = webUtteranceId;
            this.language = language;
            this.rate = rate;
            this.pitch = pitch;
            this.chunks = chunks;
        }
    }


    private final Runnable fullscreenGuardRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isFinishing()
                    && !(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) {
                enterImmersiveMode();
                handler.postDelayed(this, FULLSCREEN_GUARD_INTERVAL_MS);
            }
        }
    };


    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_exam);

        initialUrl = getIntent().getStringExtra(EXTRA_URL);
        strictMode = getIntent().getBooleanExtra(EXTRA_STRICT_MODE, true);
        testMode = getIntent().getBooleanExtra(EXTRA_TEST_MODE, false);
        if (TextUtils.isEmpty(initialUrl)) {
            Toast.makeText(this, "Alamat server tidak tersedia", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (strictMode) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }

        webView = findViewById(R.id.examWebView);
        progressBar = findViewById(R.id.pageProgress);
        fullscreenVideoContainer = findViewById(R.id.fullscreenVideoContainer);
        setupBackHandling();
        setupWebView();
        textToSpeech = new TextToSpeech(this, this);
        enterImmersiveMode();
        startFullscreenGuard();
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(visibility ->
                handler.postDelayed(this::enterImmersiveMode, 120L));
        webView.loadUrl(initialUrl);

        if (strictMode) {
            webView.postDelayed(this::startExamLockTask, 800);
        }
    }

    private void setupBackHandling() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            backCallback = this::handleSystemBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            handleSystemBack();
        }
    }

    private void handleSystemBack() {
        if (customVideoView != null) {
            hideCustomVideo();
            return;
        }
        confirmExit();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setUserAgentString(settings.getUserAgentString() + " ExamVoiceBrowser/" + BuildConfig.VERSION_NAME);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new VoiceBridge(), "ExamVoiceNative");
        installDocumentStartVoiceCompatibility();
        webView.setWebViewClient(new ExamWebViewClient());
        webView.setWebChromeClient(new ExamWebChromeClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (strictMode) {
                Toast.makeText(this, "Unduhan diblokir dalam mode ujian ketat", Toast.LENGTH_LONG).show();
            } else {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception error) {
                    Toast.makeText(this, "Tidak ada aplikasi untuk membuka unduhan", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private class ExamWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(5);
            injectVoiceCompatibility();
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            injectVoiceCompatibility();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progressBar.setProgress(100);
            handler.postDelayed(() -> progressBar.setVisibility(View.GONE), 250);
            injectVoiceCompatibility();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleNavigation(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleNavigation(Uri.parse(url));
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return interceptLocalTest(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            return interceptLocalTest(Uri.parse(url));
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                String message = error == null ? "Gagal membuka server" : error.getDescription().toString();
                Toast.makeText(ExamActivity.this, message, Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            Toast.makeText(ExamActivity.this,
                    "Sertifikat HTTPS server tidak valid. Gunakan sertifikat yang sah atau alamat HTTP lokal.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private class ExamWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            progressBar.setProgress(newProgress);
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> handleWebPermissionRequest(request));
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            runOnUiThread(() -> {
                if (pendingWebPermission == request) {
                    pendingWebPermission = null;
                }
            });
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            showCustomVideo(view, callback);
        }

        @Override
        public void onHideCustomView() {
            hideCustomVideo();
        }

        @Override
        public boolean onShowFileChooser(WebView webView,
                                         ValueCallback<Uri[]> callback,
                                         FileChooserParams fileChooserParams) {
            if (strictMode) {
                Toast.makeText(ExamActivity.this,
                        "Pemilih file dinonaktifkan dalam mode ujian ketat", Toast.LENGTH_LONG).show();
                return false;
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;
            try {
                Intent chooser = fileChooserParams.createIntent();
                startActivityForResult(chooser, REQUEST_FILE);
                return true;
            } catch (Exception error) {
                filePathCallback = null;
                Toast.makeText(ExamActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    private boolean handleNavigation(Uri uri) {
        if (uri == null || uri.getScheme() == null) {
            return true;
        }
        String scheme = uri.getScheme().toLowerCase(Locale.ROOT);
        if ("http".equals(scheme) || "https".equals(scheme)) {
            return false;
        }
        Toast.makeText(this, "Tautan eksternal diblokir: " + scheme, Toast.LENGTH_SHORT).show();
        return true;
    }

    private WebResourceResponse interceptLocalTest(Uri uri) {
        if (uri == null
                || !"examvoice.local".equalsIgnoreCase(uri.getHost())
                || !"/media-test".equals(uri.getPath())) {
            return null;
        }
        try {
            InputStream input = getAssets().open("media_test.html");
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            headers.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("text/html", "UTF-8", 200, "OK", headers, input);
        } catch (IOException error) {
            return null;
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) {
            return;
        }
        if (pendingWebPermission != null && pendingWebPermission != request) {
            pendingWebPermission.deny();
        }
        pendingWebPermission = request;

        List<String> missing = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                    && !missing.contains(Manifest.permission.CAMERA)) {
                missing.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                    && !missing.contains(Manifest.permission.RECORD_AUDIO)) {
                missing.add(Manifest.permission.RECORD_AUDIO);
            }
        }

        if (missing.isEmpty()) {
            grantPendingWebPermission();
        } else {
            requestPermissions(missing.toArray(new String[0]), REQUEST_WEB_MEDIA);
        }
    }

    private void grantPendingWebPermission() {
        PermissionRequest request = pendingWebPermission;
        pendingWebPermission = null;
        if (request == null) {
            return;
        }
        List<String> allowed = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                allowed.add(resource);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                allowed.add(resource);
            }
        }
        if (allowed.isEmpty()) {
            request.deny();
        } else {
            request.grant(allowed.toArray(new String[0]));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WEB_MEDIA) {
            grantPendingWebPermission();
        }
    }

    /**
     * Memasang kompatibilitas Web Speech API sebelum skrip halaman berjalan.
     * Setiap frame memiliki ID sendiri supaya event onstart/onend kembali ke
     * iframe yang benar. Ini penting untuk halaman Google Apps Script.
     */
    private void installDocumentStartVoiceCompatibility() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                    webView,
                    voiceCompatibilityScript(),
                    Collections.singleton("*"));
        }
    }

    private void injectVoiceCompatibility() {
        if (webView != null) {
            webView.evaluateJavascript(voiceCompatibilityScript(), null);
        }
    }

    private String voiceCompatibilityScript() {
        return """
                (function(){
                  if(window.__examVoicePolyfillInstalled){return;}
                  window.__examVoicePolyfillInstalled=true;

                  var frameId='evf_'+Date.now()+'_'+Math.random().toString(36).slice(2);
                  var active={};
                  var seq=0;
                  var startedCount=0;
                  var synthListeners={};
                  var collectSeen={};
                  var collectPending={};

                  function makeEvent(type,u,extra){
                    var e={type:type,utterance:u,target:u,currentTarget:u,timeStamp:Date.now()};
                    if(extra){for(var k in extra){try{e[k]=extra[k];}catch(x){}}}
                    return e;
                  }

                  function fire(u,type,extra){
                    var e=makeEvent(type,u,extra);
                    var prop=u&&u['on'+type];
                    try{if(typeof prop==='function')prop.call(u,e);}catch(x){}
                    var list=(u&&u.__listeners&&u.__listeners[type])?u.__listeners[type].slice():[];
                    for(var i=0;i<list.length;i++){try{list[i].call(u,e);}catch(x){}}
                  }

                  function U(text){
                    this.text=String(text||'');
                    this.lang='id-ID';
                    this.rate=1;
                    this.pitch=1;
                    this.volume=1;
                    this.voice=null;
                    this.onstart=null;
                    this.onend=null;
                    this.onerror=null;
                    this.onpause=null;
                    this.onresume=null;
                    this.onmark=null;
                    this.onboundary=null;
                    this.__listeners={};
                  }

                  U.prototype.addEventListener=function(type,fn){
                    if(typeof fn!=='function')return;
                    type=String(type||'');
                    if(!this.__listeners[type])this.__listeners[type]=[];
                    if(this.__listeners[type].indexOf(fn)<0)this.__listeners[type].push(fn);
                  };
                  U.prototype.removeEventListener=function(type,fn){
                    var a=this.__listeners[String(type||'')]||[];
                    var i=a.indexOf(fn);
                    if(i>=0)a.splice(i,1);
                  };
                  U.prototype.dispatchEvent=function(e){
                    if(!e||!e.type)return true;
                    fire(this,String(e.type),e);
                    return true;
                  };

                  try{window.SpeechSynthesisUtterance=U;}catch(e){}

                  function refreshState(){
                    var keys=Object.keys(active);
                    var waiting=0;
                    for(var i=0;i<keys.length;i++){
                      if(!active[keys[i]].__evStarted)waiting++;
                    }
                    api.speaking=startedCount>0;
                    api.pending=waiting>0;
                  }

                  function dispatch(id,type){
                    var u=active[id];
                    if(!u)return;
                    if(type==='start'){
                      if(!u.__evStarted){u.__evStarted=true;startedCount++;}
                      refreshState();
                      fire(u,'start');
                    }else if(type==='end'){
                      if(u.__evStarted)startedCount=Math.max(0,startedCount-1);
                      delete active[id];
                      refreshState();
                      fire(u,'end');
                    }else{
                      if(u.__evStarted)startedCount=Math.max(0,startedCount-1);
                      delete active[id];
                      refreshState();
                      fire(u,'error',{error:'synthesis-failed'});
                    }
                  }

                  function registerNativeUtterance(text,lang,rate,pitch,segments){
                    var u=new window.SpeechSynthesisUtterance(String(text||''));
                    u.lang=lang||'id-ID';
                    u.rate=Number(rate||1);
                    u.pitch=Number(pitch||1);
                    var id='ev_'+Date.now()+'_'+(++seq);
                    u.__evStarted=false;
                    active[id]=u;
                    refreshState();
                    try{
                      if(segments&&segments.length&&ExamVoiceNative.speakSegments){
                        ExamVoiceNative.speakSegments(
                          JSON.stringify(segments),u.lang,u.rate,u.pitch,frameId,id
                        );
                      }else{
                        ExamVoiceNative.speak(u.text,u.lang,u.rate,u.pitch,frameId,id);
                      }
                    }catch(e){dispatch(id,'error');}
                    return u;
                  }

                  var api={
                    speaking:false,
                    pending:false,
                    paused:false,
                    onvoiceschanged:null,
                    speak:function(u){
                      if(!u)return;
                      var id='ev_'+Date.now()+'_'+(++seq);
                      u.__evStarted=false;
                      active[id]=u;
                      refreshState();
                      try{
                        ExamVoiceNative.speak(
                          String(u.text||''),String(u.lang||'id-ID'),
                          Number(u.rate||1),Number(u.pitch||1),frameId,id
                        );
                      }catch(e){dispatch(id,'error');}
                    },
                    cancel:function(){
                      active={};
                      startedCount=0;
                      this.speaking=false;
                      this.pending=false;
                      this.paused=false;
                      try{ExamVoiceNative.stop();}catch(e){}
                    },
                    pause:function(){this.paused=true;},
                    resume:function(){this.paused=false;},
                    getVoices:function(){
                      return [{voiceURI:'android-tts-id',name:'Android Text-to-Speech',lang:'id-ID',localService:true,default:true}];
                    },
                    addEventListener:function(type,fn){
                      if(typeof fn!=='function')return;
                      type=String(type||'');
                      if(!synthListeners[type])synthListeners[type]=[];
                      if(synthListeners[type].indexOf(fn)<0)synthListeners[type].push(fn);
                    },
                    removeEventListener:function(type,fn){
                      var a=synthListeners[String(type||'')]||[];
                      var i=a.indexOf(fn);
                      if(i>=0)a.splice(i,1);
                    },
                    dispatchEvent:function(e){
                      if(!e||!e.type)return true;
                      var a=(synthListeners[e.type]||[]).slice();
                      for(var i=0;i<a.length;i++){try{a[i].call(api,e);}catch(x){}}
                      return true;
                    }
                  };

                  try{
                    Object.defineProperty(window,'speechSynthesis',{value:api,configurable:true,writable:true});
                  }catch(e){window.speechSynthesis=api;}

                  window.__examVoiceReceive=function(m){
                    if(!m||m.__examVoiceEvent!==true)return;
                    if(m.frameId===frameId){
                      dispatch(String(m.utteranceId||''),String(m.eventType||''));
                    }
                    try{
                      var fs=document.querySelectorAll('iframe,frame');
                      for(var i=0;i<fs.length;i++){
                        if(fs[i].contentWindow){fs[i].contentWindow.postMessage(m,'*');}
                      }
                    }catch(e){}
                  };

                  function compactText(value){
                    return String(value||'')
                      .replace(/\\u00a0/g,' ')
                      .replace(/[\\t\\f ]+/g,' ')
                      .replace(/ *\\n+ */g,'\\n')
                      .trim();
                  }

                  function isVisible(el){
                    if(!el||el.nodeType!==1)return false;
                    try{
                      var st=window.getComputedStyle(el);
                      if(!st||st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return false;
                      var r=el.getBoundingClientRect();
                      return r.width>0&&r.height>0;
                    }catch(e){return true;}
                  }

                  // Elemen pilihan dapat menyimpan teks di data-option/data-answer tanpa
                  // memiliki ukuran sendiri. Elemen tetap dianggap aktif jika berada di
                  // dalam kartu soal yang terlihat dan tidak mempunyai ancestor tersembunyi.
                  function hasVisibleContext(el){
                    if(!el||el.nodeType!==1)return false;
                    if(isVisible(el))return true;
                    try{
                      var node=el;
                      for(var depth=0;node&&depth<10;depth++,node=node.parentElement){
                        var st=window.getComputedStyle(node);
                        if(!st||st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return false;
                        var r=node.getBoundingClientRect();
                        if(r.width>0&&r.height>0)return true;
                      }
                    }catch(e){}
                    return false;
                  }

                  function controlLabel(el){
                    if(!el)return '';
                    var values=[];
                    // Atribut aksesibilitas harus didahulukan. Tombol bersuara sering
                    // hanya menampilkan ikon sehingga innerText-nya berupa simbol 🔊.
                    try{
                      values.push(
                        el.getAttribute('aria-label'),
                        el.getAttribute('title'),
                        el.getAttribute('data-label'),
                        el.getAttribute('data-text')
                      );
                    }catch(e){}
                    // Utamakan tulisan yang benar-benar terlihat sebelum value/data-value.
                    // Ini mencegah jawaban "Jakarta" terbaca hanya sebagai "A".
                    try{values.push(el.innerText,el.textContent);}catch(e){}
                    try{
                      values.push(
                        el.getAttribute('data-option'),
                        el.getAttribute('data-answer'),
                        el.getAttribute('data-choice'),
                        el.getAttribute('data-value'),
                        el.getAttribute('value')
                      );
                    }catch(e){}
                    try{
                      var imgs=el.querySelectorAll?el.querySelectorAll('img[alt]'):[];
                      for(var i=0;i<imgs.length;i++)values.push(imgs[i].getAttribute('alt'));
                    }catch(e){}
                    for(var j=0;j<values.length;j++){
                      var value=compactText(values[j]);
                      if(value)return value;
                    }
                    return '';
                  }

                  function isChoiceControlVisible(el){
                    if(!el)return false;
                    if(hasVisibleContext(el))return true;
                    try{
                      if(el.labels){
                        for(var i=0;i<el.labels.length;i++)if(isVisible(el.labels[i]))return true;
                      }
                    }catch(e){}
                    try{
                      var host=el.closest('label,[role="radio"],[role="checkbox"],.form-check,.option,.choice,.answer,.jawaban,.pilihan,.opsi,.option-item,.choice-item,.answer-item,[data-option],[data-answer],[data-choice],[data-value]');
                      if(host&&isVisible(host))return true;
                    }catch(e){}
                    return !!(el.parentElement&&isVisible(el.parentElement));
                  }

                  function uniquePush(list,value){
                    value=compactText(value);
                    if(!value||value.length>600)return;
                    var key=value.toLowerCase().replace(/[^a-z0-9\\u00c0-\\u024f\\u0600-\\u06ff]+/g,' ').trim();
                    if(!key)return;
                    for(var i=0;i<list.length;i++){
                      var old=String(list[i]||'').toLowerCase().replace(/[^a-z0-9\\u00c0-\\u024f\\u0600-\\u06ff]+/g,' ').trim();
                      if(old===key)return;
                    }
                    list.push(value);
                  }

                  function choiceText(el){
                    if(!el)return '';
                    var candidates=[];
                    try{
                      if(el.labels){for(var i=0;i<el.labels.length;i++)candidates.push(el.labels[i]);}
                      var id=el.getAttribute&&el.getAttribute('id');
                      if(id){
                        var linked=null;
                        try{
                          if(window.CSS&&CSS.escape)linked=document.querySelector('label[for="'+CSS.escape(id)+'"]');
                        }catch(x){}
                        if(!linked){
                          var labels=document.getElementsByTagName('label');
                          for(var li=0;li<labels.length;li++){
                            if(labels[li].getAttribute('for')===id){linked=labels[li];break;}
                          }
                        }
                        if(linked)candidates.push(linked);
                      }
                    }catch(e){}
                    try{
                      var closest=el.closest('label,[role="radio"],[role="checkbox"],.form-check,.option,.choice,.answer,.jawaban,.pilihan,.opsi,.option-item,.choice-item,.answer-item,.answer-option,.quiz-option,[data-option],[data-answer],[data-choice],[data-value]');
                      if(closest)candidates.push(closest);
                    }catch(e){}
                    if(el.parentElement)candidates.push(el.parentElement);
                    if(el.nextElementSibling)candidates.push(el.nextElementSibling);
                    if(el.previousElementSibling)candidates.push(el.previousElementSibling);
                    candidates.push(el);
                    for(var j=0;j<candidates.length;j++){
                      if(!candidates[j])continue;
                      var text=controlLabel(candidates[j]);
                      text=text.replace(/^(?:(?:pilihan|opsi|jawaban|option|answer)\\s+[A-H](?:[.)\\-:]|\\s)\\s*|[A-H][.)\\-:]\\s*)/i,'').trim();
                      if(text&&text.length<=500&&!/^(radio|checkbox|true|false)$/i.test(text))return text;
                    }
                    try{
                      var value=compactText(el.value||el.getAttribute('value')||'');
                      if(value&&!/^(on|true|false|[A-H]|\\d+)$/i.test(value))return value;
                    }catch(e){}
                    return '';
                  }

                  function collectChoiceRecords(scope,allowInteractive){
                    scope=scope||document;
                    allowInteractive=allowInteractive===true;
                    var records=[];
                    var seen=[];
                    function add(el,text){
                      text=compactText(text);
                      if(!text||text.length>500)return;
                      var key=text.toLowerCase().replace(/^(?:(?:pilihan|opsi|jawaban|option|answer)\\s+[A-H](?:[.)\\-:]|\\s)\\s*|[A-H][.)\\-:]\\s*)/i,'').trim();
                      if(!key)return;
                      for(var i=0;i<seen.length;i++)if(seen[i]===key)return;
                      seen.push(key);
                      records.push({el:el,text:text});
                    }
                    try{
                      var controls=scope.querySelectorAll('input[type="radio"],input[type="checkbox"],[role="radio"],[role="checkbox"]');
                      for(var i=0;i<controls.length;i++){
                        if(isChoiceControlVisible(controls[i]))add(controls[i],choiceText(controls[i]));
                      }
                    }catch(e){}
                    if(records.length<2){
                      try{
                        var generic=scope.querySelectorAll('label,.option,.choice,.answer,.jawaban,.pilihan,.opsi,.option-item,.choice-item,.answer-item,.answer-option,.quiz-option,[data-option],[data-answer],[data-choice],[data-value],[class*="option"],[class*="choice"],[class*="answer"],[class*="jawaban"],[class*="pilihan"],[class*="opsi"]');
                        for(var g=0;g<generic.length;g++){
                          var el=generic[g];
                          if(!hasVisibleContext(el))continue;
                          var text=controlLabel(el);
                          if(!text||text.length>500)continue;
                          var nested=el.querySelectorAll('label,.option,.choice,.answer,.jawaban,.pilihan,.opsi,.option-item,.choice-item,.answer-item,[role="radio"],[role="checkbox"]').length;
                          if(nested>1)continue;
                          if(/^(bacakan|baca|dengar|audio|suara|stop|hentikan|selanjutnya|sebelumnya|submit|selesai|kirim)/i.test(text))continue;
                          add(el,text);
                        }
                      }catch(e){}
                    }
                    // Beberapa aplikasi ujian membuat pilihan sebagai tombol biasa tanpa
                    // class "option". Ambil tombol di dalam kartu soal, tetapi singkirkan
                    // tombol navigasi, kontrol suara, submit, dan penanda ragu-ragu.
                    if(records.length<2&&allowInteractive&&scope!==document&&scope!==document.body&&scope!==document.documentElement){
                      try{
                        var clickable=scope.querySelectorAll('button,[role="option"],[role="menuitemradio"],[role="menuitemcheckbox"],[data-value]');
                        for(var b=0;b<clickable.length;b++){
                          var item=clickable[b];
                          if(!isVisible(item))continue;
                          var label=controlLabel(item);
                          if(!label||label.length>500)continue;
                          if(/^(bacakan|baca|dengarkan|dengar|suara|audio|read|stop|hentikan|berhenti|selanjutnya|berikutnya|sebelumnya|kembali|submit|kirim|selesai|muat ulang|keluar|tandai|ragu|hapus jawaban|reset)/i.test(label))continue;
                          add(item,label);
                        }
                      }catch(e){}
                    }
                    records.sort(function(a,b){
                      if(a.el===b.el)return 0;
                      try{return a.el.compareDocumentPosition(b.el)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1;}catch(e){return 0;}
                    });
                    return records;
                  }

                  function commonAncestor(a,b){
                    if(!a||!b)return null;
                    var parents=[];
                    for(var n=a;n;n=n.parentElement)parents.push(n);
                    for(var m=b;m;m=m.parentElement)if(parents.indexOf(m)>=0)return m;
                    return null;
                  }

                  function findQuestionRoot(control,records){
                    var root=null;
                    var semantic='[data-question],[data-question-id],article,fieldset,.question,.question-card,.question-container,.quiz-question,.soal,.soal-card,.pertanyaan,.pertanyaan-card';
                    if(control){
                      try{
                        var semanticRoot=control.closest(semantic);
                        if(semanticRoot&&collectChoiceRecords(semanticRoot,true).length>=2)root=semanticRoot;
                      }catch(e){}
                      if(!root){
                        var node=control;
                        for(var d=0;node&&d<16;d++,node=node.parentElement){
                          var count=collectChoiceRecords(node,true).length;
                          if(count>=2&&count<=16){root=node;break;}
                        }
                      }
                    }
                    if(!root&&records&&records.length>=2){
                      var groups={};
                      for(var r=0;r<records.length;r++){
                        var el=records[r].el;
                        var name='';
                        try{name=el.getAttribute&&el.getAttribute('name')||'';}catch(e){}
                        if(name){if(!groups[name])groups[name]=[];groups[name].push(records[r]);}
                      }
                      var bestGroup=null;
                      for(var key in groups){
                        var group=groups[key];
                        if(group.length>=2&&group.length<=12&&(!bestGroup||group.length>bestGroup.length))bestGroup=group;
                      }
                      var source=bestGroup||records;
                      root=commonAncestor(source[0].el,source[source.length-1].el);
                    }
                    if(!root)root=document.body||document.documentElement;
                    for(var up=0;root&&root.parentElement&&up<4;up++){
                      var own=compactText(root.innerText||root.textContent||'');
                      if(/(pertanyaan|question|soal)\\s*(no\\.?|nomor|number)?/i.test(own))break;
                      var localChoices=collectChoiceRecords(root,true);
                      var choiceChars=0;
                      for(var lc=0;lc<localChoices.length;lc++)choiceChars+=compactText(localChoices[lc].text).length;
                      if(localChoices.length>=2&&own.length>choiceChars+30)break;
                      var parentText=compactText(root.parentElement.innerText||root.parentElement.textContent||'');
                      if(parentText.length>0&&parentText.length<Math.max(own.length*3,3000))root=root.parentElement;
                      else break;
                    }
                    return root;
                  }

                  function cleanQuestionLines(root,choiceTexts){
                    var raw='';
                    var preferred=[];
                    try{
                      var questionNodes=root.querySelectorAll('[data-question-text],.question-text,.question-title,.question-content,.soal-text,.soal-title,.teks-soal,.pertanyaan-text,legend,[role="heading"]');
                      for(var n=0;n<questionNodes.length&&n<8;n++){
                        if(isVisible(questionNodes[n]))uniquePush(preferred,controlLabel(questionNodes[n]));
                      }
                    }catch(e){}
                    if(preferred.length)raw=preferred.join('\\n');
                    if(!raw){try{raw=compactText(root.innerText||root.textContent||'');}catch(e){}}
                    var lines=raw.split(/\\n+/);
                    var cleaned=[];
                    var previous='';
                    for(var i=0;i<lines.length;i++){
                      var line=compactText(lines[i]);
                      if(!line)continue;
                      if(/^\\d{1,2}:\\d{2}(?::\\d{2})?$/.test(line))continue;
                      if(/^(bacakan.*|baca.*soal.*|dengar.*soal.*|stop.*|hentikan.*|pertanyaan sebelumnya|pertanyaan selanjutnya|sebelumnya|selanjutnya|submit|kirim|selesai ujian|muat ulang|keluar)$/i.test(line))continue;
                      var normalizedLine=line.toLowerCase().replace(/^(?:(?:pilihan|opsi|jawaban|option|answer)\\s+[A-H](?:[.)\\-:]|\\s)\\s*|[A-H][.)\\-:]\\s*)/i,'').trim();
                      var isChoice=false;
                      for(var c=0;c<choiceTexts.length;c++){
                        var normalizedChoice=String(choiceTexts[c]||'').toLowerCase().replace(/^(?:(?:pilihan|opsi|jawaban|option|answer)\\s+[A-H](?:[.)\\-:]|\\s)\\s*|[A-H][.)\\-:]\\s*)/i,'').trim();
                        if(normalizedLine===normalizedChoice){isChoice=true;break;}
                      }
                      if(isChoice||line===previous)continue;
                      cleaned.push(line);
                      previous=line;
                    }
                    var q=-1;
                    for(var j=0;j<cleaned.length;j++){
                      if(/(pertanyaan|question|soal)\\s*(no\\.?|nomor|number)?/i.test(cleaned[j])){q=j;break;}
                    }
                    if(q>0)cleaned=cleaned.slice(q);
                    if(cleaned.length>12)cleaned=cleaned.slice(0,12);
                    return cleaned;
                  }

                  function extractQuestionPackage(control){
                    var allRecords=collectChoiceRecords(document,false);
                    var root=findQuestionRoot(control,allRecords);
                    var scoped=collectChoiceRecords(root,true);
                    var records=scoped.length>=2?scoped:allRecords;
                    var choices=[];
                    for(var i=0;i<records.length&&choices.length<12;i++)uniquePush(choices,records[i].text);
                    var question=cleanQuestionLines(root,choices);
                    var choiceSegments=[];
                    for(var c=0;c<choices.length;c++){
                      var letter=String.fromCharCode(65+c);
                      var value=choices[c].replace(/^(?:(?:pilihan|opsi|jawaban|option|answer)\\s+[A-H](?:[.)\\-:]|\\s)\\s*|[A-H][.)\\-:]\\s*)/i,'').trim();
                      choiceSegments.push('Pilihan '+letter+'. '+value+'.');
                    }
                    var segments=[];
                    for(var q=0;q<question.length;q++)uniquePush(segments,question[q]);
                    for(var x=0;x<choiceSegments.length;x++)uniquePush(segments,choiceSegments[x]);
                    var questionChars=question.join(' ').length;
                    return {
                      frameId:frameId,
                      questionSegments:question,
                      choiceSegments:choiceSegments,
                      segments:segments,
                      choices:choiceSegments.length,
                      score:((control&&choiceSegments.length>=2)?2500:0)+(choiceSegments.length*10000)+(questionChars*5)+segments.join(' ').length
                    };
                  }

                  function sendToChildren(message){
                    try{
                      var fs=document.querySelectorAll('iframe,frame');
                      for(var i=0;i<fs.length;i++)if(fs[i].contentWindow)fs[i].contentWindow.postMessage(message,'*');
                    }catch(e){}
                  }

                  function postCollectResult(requestId,payload){
                    try{window.top.postMessage({__examVoiceCollectResult:true,requestId:requestId,payload:payload},'*');}catch(e){}
                  }

                  function finalizeCollection(requestId){
                    var pending=collectPending[requestId];
                    if(!pending)return;
                    delete collectPending[requestId];
                    var results=pending.results||[];
                    if(!results.length){results.push(extractQuestionPackage(pending.control));}
                    var best=null;
                    var bestQuestion=null;
                    for(var i=0;i<results.length;i++){
                      var r=results[i];
                      if(!r||!r.segments||!r.segments.length)continue;
                      if(!best||Number(r.score||0)>Number(best.score||0))best=r;
                      if(r.questionSegments&&r.questionSegments.length&&(!bestQuestion||r.questionSegments.join(' ').length>bestQuestion.questionSegments.join(' ').length))bestQuestion=r;
                    }
                    if(!best){
                      try{ExamVoiceNative.notify('Teks soal dan pilihan jawaban tidak ditemukan pada halaman ini.');}catch(e){}
                      return;
                    }
                    var finalSegments=[];
                    if((!best.questionSegments||!best.questionSegments.length)&&bestQuestion&&bestQuestion!==best){
                      for(var q=0;q<bestQuestion.questionSegments.length;q++)uniquePush(finalSegments,bestQuestion.questionSegments[q]);
                    }else if(best.questionSegments){
                      for(var bq=0;bq<best.questionSegments.length;bq++)uniquePush(finalSegments,best.questionSegments[bq]);
                    }
                    if(best.choiceSegments){for(var c=0;c<best.choiceSegments.length;c++)uniquePush(finalSegments,best.choiceSegments[c]);}
                    if(!finalSegments.length)finalSegments=best.segments.slice();
                    api.cancel();
                    registerNativeUtterance(finalSegments.join('. '),'id-ID',0.95,1,finalSegments);
                  }

                  function readCompleteQuestion(control){
                    var requestId='collect_'+Date.now()+'_'+Math.random().toString(36).slice(2);
                    // Simpan hasil frame saat ini terlebih dahulu. Dengan begitu tombol tetap
                    // bekerja walau postMessage antar-frame dibatasi oleh halaman ujian.
                    collectPending[requestId]={results:[extractQuestionPackage(control)],control:control||null};
                    try{window.top.postMessage({__examVoiceCollectRequest:true,requestId:requestId},'*');}catch(e){}
                    setTimeout(function(){finalizeCollection(requestId);},700);
                    return true;
                  }

                  window.addEventListener('message',function(e){
                    var m=e.data;
                    if(!m)return;
                    if(m.__examVoiceEvent===true){window.__examVoiceReceive(m);return;}
                    if(m.__examVoiceCollectRequest===true){
                      var rid=String(m.requestId||'');
                      if(!rid||collectSeen[rid])return;
                      collectSeen[rid]=true;
                      postCollectResult(rid,extractQuestionPackage(null));
                      sendToChildren(m);
                      return;
                    }
                    if(m.__examVoiceCollectResult===true){
                      if(window===window.top)sendToChildren(m);
                      var wait=collectPending[String(m.requestId||'')];
                      if(wait&&m.payload){wait.results.push(m.payload);}
                    }
                  },false);

                  function isReadControl(label){
                    label=compactText(label).toLowerCase();
                    if(!label)return false;
                    return /(bacakan|baca|dengarkan|dengar|suara|audio|read)/i.test(label)
                      && /(soal|pertanyaan|question)/i.test(label);
                  }

                  function interceptRead(event){
                    var target=event.target;
                    var control=null;
                    try{control=target&&target.closest?target.closest('button,a,[role="button"],input[type="button"],input[type="submit"],.btn'):target;}catch(e){control=target;}
                    var label=controlLabel(control);
                    if(isReadControl(label)){
                      event.preventDefault();
                      event.stopPropagation();
                      if(event.stopImmediatePropagation)event.stopImmediatePropagation();
                      readCompleteQuestion(control);
                      return false;
                    }
                    if(/^(stop audio|hentikan suara|stop suara|berhenti membaca)$/i.test(label)){
                      event.preventDefault();
                      event.stopPropagation();
                      if(event.stopImmediatePropagation)event.stopImmediatePropagation();
                      api.cancel();
                      return false;
                    }
                  }

                  // Hanya cegat event click. Mencegah default pada touchstart/pointerdown
                  // dapat membatalkan event click di Android WebView sehingga suara tidak mulai.
                  document.addEventListener('click',interceptRead,true);
                  document.addEventListener('keydown',function(event){
                    if(event.key==='Enter'||event.key===' '){interceptRead(event);}
                  },true);

                  window.ExamVoice=window.ExamVoice||{};
                  window.ExamVoice.speak=function(t){
                    var u=new window.SpeechSynthesisUtterance(String(t||''));
                    u.lang='id-ID';
                    api.speak(u);
                  };
                  window.ExamVoice.stop=function(){api.cancel();};
                  window.ExamVoice.readQuestionAndAnswers=function(control){return readCompleteQuestion(control||null);};

                  setTimeout(function(){
                    try{
                      var ev={type:'voiceschanged',target:api,currentTarget:api};
                      if(typeof api.onvoiceschanged==='function')api.onvoiceschanged(ev);
                      api.dispatchEvent(ev);
                      window.dispatchEvent(new Event('voiceschanged'));
                    }catch(e){}
                  },0);
                })();
                """;
    }

    private void enqueueSpeechFromWeb(String text,
                                      String language,
                                      float rate,
                                      float pitch,
                                      String frameId,
                                      String utteranceId) {
        if (TextUtils.isEmpty(utteranceId)) {
            return;
        }
        if (TextUtils.isEmpty(text)) {
            dispatchVoiceEvent(frameId, utteranceId, "end");
            return;
        }

        String normalized = normalizeSpeechText(text);
        List<String> chunks = splitSpeechText(normalized);
        if (chunks.isEmpty()) {
            dispatchVoiceEvent(frameId, utteranceId, "end");
            return;
        }

        speechQueue.addLast(new SpeechJob(
                frameId,
                utteranceId,
                language,
                clamp(rate, 0.25f, 2.0f),
                clamp(pitch, 0.5f, 2.0f),
                chunks));

        if (ttsReady) {
            startNextSpeechJob();
        }
    }

    private void enqueueSpeechSegmentsFromWeb(String segmentsJson,
                                              String language,
                                              float rate,
                                              float pitch,
                                              String frameId,
                                              String utteranceId) {
        if (TextUtils.isEmpty(utteranceId)) {
            return;
        }

        List<String> chunks = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(segmentsJson == null ? "[]" : segmentsJson);
            for (int index = 0; index < array.length(); index++) {
                String segment = normalizeSpeechText(array.optString(index, ""));
                if (TextUtils.isEmpty(segment)) {
                    continue;
                }
                List<String> segmentChunks = splitSpeechText(segment);
                if (segmentChunks.isEmpty()) {
                    continue;
                }
                chunks.addAll(segmentChunks);
            }
        } catch (Exception error) {
            dispatchVoiceEvent(frameId, utteranceId, "error");
            return;
        }

        if (chunks.isEmpty()) {
            dispatchVoiceEvent(frameId, utteranceId, "end");
            return;
        }

        speechQueue.addLast(new SpeechJob(
                frameId,
                utteranceId,
                language,
                clamp(rate, 0.25f, 2.0f),
                clamp(pitch, 0.5f, 2.0f),
                chunks));

        if (ttsReady) {
            startNextSpeechJob();
        }
    }

    private String normalizeSpeechText(String text) {
        return text
                .replace("\r\n", "\n")
                .replace('\r', '\n')
                .replaceAll("[\\t\\f ]+", " ")
                .replaceAll(" *\\n+ *", ". ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private List<String> splitSpeechText(String text) {
        List<String> chunks = new ArrayList<>();
        int platformLimit = TextToSpeech.getMaxSpeechInputLength();
        int maximumLength = Math.max(120, Math.min(SPEECH_CHUNK_LIMIT, platformLimit - 100));

        // Pecah lebih dahulu pada akhir kalimat. Ini membuat soal dan setiap
        // pilihan jawaban dibaca sebagai unit tersendiri, bukan satu teks
        // panjang yang mudah dipotong oleh mesin TTS vendor.
        String[] sentences = text.split("(?<=[.!?;:])\\s+");
        for (String sentence : sentences) {
            appendSpeechChunks(chunks, sentence.trim(), maximumLength);
        }
        return chunks;
    }

    private void appendSpeechChunks(List<String> chunks, String text, int maximumLength) {
        if (TextUtils.isEmpty(text)) {
            return;
        }
        int start = 0;
        while (start < text.length()) {
            int hardEnd = Math.min(start + maximumLength, text.length());
            int end = hardEnd;
            if (hardEnd < text.length()) {
                int minimumBreak = start + Math.max(40, maximumLength / 2);
                int best = -1;
                char[] separators = new char[]{'.', '?', '!', ';', ':', ','};
                for (char separator : separators) {
                    int candidate = text.lastIndexOf(separator, hardEnd);
                    if (candidate >= minimumBreak) {
                        best = Math.max(best, candidate + 1);
                    }
                }
                if (best < minimumBreak) {
                    int space = text.lastIndexOf(' ', hardEnd);
                    if (space >= minimumBreak) {
                        best = space;
                    }
                }
                if (best > start) {
                    end = best;
                }
            }

            String chunk = text.substring(start, end).trim();
            if (!chunk.isEmpty()) {
                chunks.add(chunk);
            }
            start = Math.max(end, start + 1);
            while (start < text.length() && Character.isWhitespace(text.charAt(start))) {
                start++;
            }
        }
    }

    private void startNextSpeechJob() {
        if (!ttsReady || textToSpeech == null || activeSpeechJob != null) {
            return;
        }
        activeSpeechJob = speechQueue.pollFirst();
        if (activeSpeechJob == null) {
            return;
        }
        activeSpeechChunkIndex = 0;
        speakActiveChunk();
    }

    private void speakActiveChunk() {
        SpeechJob job = activeSpeechJob;
        if (job == null || textToSpeech == null) {
            return;
        }
        if (activeSpeechChunkIndex < 0 || activeSpeechChunkIndex >= job.chunks.size()) {
            finishActiveSpeechJob("end");
            return;
        }

        Locale locale = localeFor(job.language, job.chunks.get(activeSpeechChunkIndex));
        int availability = textToSpeech.setLanguage(locale);
        if (availability == TextToSpeech.LANG_MISSING_DATA
                || availability == TextToSpeech.LANG_NOT_SUPPORTED) {
            int indonesia = textToSpeech.setLanguage(new Locale("id", "ID"));
            if (indonesia == TextToSpeech.LANG_MISSING_DATA
                    || indonesia == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech.setLanguage(Locale.getDefault());
            }
        }
        textToSpeech.setSpeechRate(job.rate);
        textToSpeech.setPitch(job.pitch);

        String chunk = job.chunks.get(activeSpeechChunkIndex).trim();
        if (!chunk.matches(".*[.!?;:]$")) {
            chunk = chunk + ".";
        }

        activeNativeUtteranceId = "native_" + (++nativeSpeechSequence);
        String utteranceId = activeNativeUtteranceId;
        int queueMode = activeSpeechChunkIndex == 0
                ? TextToSpeech.QUEUE_FLUSH
                : TextToSpeech.QUEUE_ADD;
        int result = textToSpeech.speak(
                chunk,
                queueMode,
                null,
                utteranceId);
        if (result == TextToSpeech.ERROR) {
            retryOrContinueActiveChunk();
        } else {
            scheduleSpeechWatchdog(utteranceId, chunk, job.rate);
        }
    }

    /**
     * Sebagian mesin TTS vendor tidak selalu mengirim callback onDone untuk
     * kalimat tertentu. Watchdog ini memastikan antrean tetap melanjutkan
     * pilihan jawaban berikutnya, tanpa memotong suara yang masih berjalan:
     * chunk berikutnya dimasukkan dengan QUEUE_ADD. Callback terlambat dari
     * chunk lama akan diabaikan karena utteranceId sudah berubah.
     */
    private void scheduleSpeechWatchdog(String utteranceId, String chunk, float rate) {
        float safeRate = Math.max(0.25f, rate);
        long estimated = (long) ((chunk.length() * 165L) / safeRate) + 5000L;
        long firstCheck = Math.max(SPEECH_WATCHDOG_MIN_MS,
                Math.min(SPEECH_WATCHDOG_MAX_MS, estimated));
        checkSpeechWatchdog(utteranceId, firstCheck, 0);
    }

    private void checkSpeechWatchdog(String utteranceId, long delayMs, int attempt) {
        handler.postDelayed(() -> {
            if (activeSpeechJob == null
                    || !TextUtils.equals(activeNativeUtteranceId, utteranceId)) {
                return;
            }

            // Jangan menganggap chunk selesai ketika mesin TTS masih benar-benar
            // berbicara. Ini mencegah pilihan jawaban terakhir dilewati.
            if (textToSpeech != null && textToSpeech.isSpeaking() && attempt < 20) {
                checkSpeechWatchdog(utteranceId, 3500L, attempt + 1);
                return;
            }

            handleNativeSpeechDone(utteranceId);
        }, delayMs);
    }

    private void handleNativeSpeechStart(String nativeUtteranceId) {
        if (!TextUtils.equals(activeNativeUtteranceId, nativeUtteranceId) || activeSpeechJob == null) {
            return;
        }
        if (activeSpeechChunkIndex == 0) {
            dispatchVoiceEvent(
                    activeSpeechJob.frameId,
                    activeSpeechJob.webUtteranceId,
                    "start");
        }
    }

    private void handleNativeSpeechDone(String nativeUtteranceId) {
        if (!TextUtils.equals(activeNativeUtteranceId, nativeUtteranceId) || activeSpeechJob == null) {
            return;
        }
        SpeechJob expectedJob = activeSpeechJob;
        long expectedGeneration = speechGeneration;
        activeSpeechRetryCount = 0;
        if (activeSpeechChunkIndex + 1 < expectedJob.chunks.size()) {
            activeSpeechChunkIndex++;
            int expectedIndex = activeSpeechChunkIndex;
            handler.postDelayed(() -> {
                if (speechGeneration == expectedGeneration
                        && activeSpeechJob == expectedJob
                        && activeSpeechChunkIndex == expectedIndex) {
                    speakActiveChunk();
                }
            }, SPEECH_GAP_MS);
        } else {
            handler.postDelayed(() -> {
                if (speechGeneration == expectedGeneration && activeSpeechJob == expectedJob) {
                    finishActiveSpeechJob("end");
                }
            }, SPEECH_GAP_MS);
        }
    }

    private void handleNativeSpeechError(String nativeUtteranceId) {
        if (!TextUtils.equals(activeNativeUtteranceId, nativeUtteranceId) || activeSpeechJob == null) {
            return;
        }
        retryOrContinueActiveChunk();
    }

    private void handleNativeSpeechStopped(String nativeUtteranceId, boolean interrupted) {
        if (userRequestedSpeechStop
                || !TextUtils.equals(activeNativeUtteranceId, nativeUtteranceId)
                || activeSpeechJob == null) {
            return;
        }
        retryOrContinueActiveChunk();
    }

    private void retryOrContinueActiveChunk() {
        if (activeSpeechJob == null) {
            return;
        }
        SpeechJob expectedJob = activeSpeechJob;
        long expectedGeneration = speechGeneration;
        if (activeSpeechRetryCount < 1) {
            activeSpeechRetryCount++;
            int expectedIndex = activeSpeechChunkIndex;
            handler.postDelayed(() -> {
                if (speechGeneration == expectedGeneration
                        && activeSpeechJob == expectedJob
                        && activeSpeechChunkIndex == expectedIndex) {
                    speakActiveChunk();
                }
            }, 300L);
            return;
        }
        activeSpeechRetryCount = 0;
        if (activeSpeechChunkIndex + 1 < expectedJob.chunks.size()) {
            activeSpeechChunkIndex++;
            int expectedIndex = activeSpeechChunkIndex;
            handler.postDelayed(() -> {
                if (speechGeneration == expectedGeneration
                        && activeSpeechJob == expectedJob
                        && activeSpeechChunkIndex == expectedIndex) {
                    speakActiveChunk();
                }
            }, SPEECH_GAP_MS);
        } else {
            handler.postDelayed(() -> {
                if (speechGeneration == expectedGeneration && activeSpeechJob == expectedJob) {
                    finishActiveSpeechJob("end");
                }
            }, SPEECH_GAP_MS);
        }
    }

    private void finishActiveSpeechJob(String eventType) {
        SpeechJob finished = activeSpeechJob;
        activeSpeechJob = null;
        activeSpeechChunkIndex = -1;
        activeNativeUtteranceId = null;
        activeSpeechRetryCount = 0;
        if (finished != null) {
            dispatchVoiceEvent(finished.frameId, finished.webUtteranceId, eventType);
        }
        long expectedGeneration = speechGeneration;
        handler.postDelayed(() -> {
            if (speechGeneration == expectedGeneration) {
                startNextSpeechJob();
            }
        }, SPEECH_GAP_MS);
    }

    private void stopAllSpeech() {
        speechGeneration++;
        speechQueue.clear();
        activeSpeechJob = null;
        activeSpeechChunkIndex = -1;
        activeNativeUtteranceId = null;
        activeSpeechRetryCount = 0;
        userRequestedSpeechStop = true;
        if (textToSpeech != null) {
            textToSpeech.stop();
        }
        handler.postDelayed(() -> userRequestedSpeechStop = false, 350L);
    }

    private Locale localeFor(String language, String text) {
        if (!TextUtils.isEmpty(language)) {
            String normalized = language.replace('_', '-');
            String[] parts = normalized.split("-");
            if (parts.length >= 2) {
                return new Locale(parts[0], parts[1]);
            }
            return new Locale(parts[0]);
        }
        if (text != null && text.matches(".*[\u0600-\u06FF].*")) {
            return new Locale("ar");
        }
        return new Locale("id", "ID");
    }

    private float clamp(float value, float min, float max) {
        if (Float.isNaN(value) || Float.isInfinite(value)) {
            return 1.0f;
        }
        return Math.max(min, Math.min(max, value));
    }

    private void dispatchVoiceEvent(String frameId, String utteranceId, String eventType) {
        if (webView == null || TextUtils.isEmpty(utteranceId)) {
            return;
        }
        String payload = "{"
                + "\"__examVoiceEvent\":true,"
                + "\"frameId\":" + JSONObject.quote(frameId == null ? "" : frameId) + ","
                + "\"utteranceId\":" + JSONObject.quote(utteranceId) + ","
                + "\"eventType\":" + JSONObject.quote(eventType)
                + "}";
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(
                        "(function(m){if(window.__examVoiceReceive){window.__examVoiceReceive(m);}else{window.postMessage(m,'*');}})("
                                + payload + ");",
                        null);
            }
        });
    }

    private void failQueuedSpeech() {
        speechGeneration++;
        if (activeSpeechJob != null) {
            dispatchVoiceEvent(activeSpeechJob.frameId, activeSpeechJob.webUtteranceId, "error");
        }
        for (SpeechJob job : speechQueue) {
            dispatchVoiceEvent(job.frameId, job.webUtteranceId, "error");
        }
        speechQueue.clear();
        activeSpeechJob = null;
        activeSpeechChunkIndex = -1;
        activeNativeUtteranceId = null;
        activeSpeechRetryCount = 0;
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
            ttsReady = true;
            textToSpeech.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            int languageStatus = textToSpeech.setLanguage(new Locale("id", "ID"));
            if (languageStatus == TextToSpeech.LANG_MISSING_DATA
                    || languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech.setLanguage(Locale.getDefault());
                Toast.makeText(this,
                        "Suara Bahasa Indonesia belum terpasang. Menggunakan suara bawaan perangkat.",
                        Toast.LENGTH_LONG).show();
            }
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    runOnUiThread(() -> {
                        if (TextUtils.equals(exitUtteranceId, utteranceId)) {
                            return;
                        }
                        handleNativeSpeechStart(utteranceId);
                    });
                }

                @Override
                public void onDone(String utteranceId) {
                    runOnUiThread(() -> {
                        if (TextUtils.equals(exitUtteranceId, utteranceId)) {
                            finishApplicationNow();
                            return;
                        }
                        handleNativeSpeechDone(utteranceId);
                    });
                }

                @Override
                public void onError(String utteranceId) {
                    runOnUiThread(() -> {
                        if (TextUtils.equals(exitUtteranceId, utteranceId)) {
                            finishApplicationNow();
                            return;
                        }
                        handleNativeSpeechError(utteranceId);
                    });
                }

                @Override
                public void onStop(String utteranceId, boolean interrupted) {
                    runOnUiThread(() -> {
                        if (TextUtils.equals(exitUtteranceId, utteranceId)) {
                            finishApplicationNow();
                            return;
                        }
                        handleNativeSpeechStopped(utteranceId, interrupted);
                    });
                }
            });
            injectVoiceCompatibility();
            startNextSpeechJob();
        } else {
            ttsReady = false;
            failQueuedSpeech();
        }
    }

    public class VoiceBridge {
        @JavascriptInterface
        public void speak(String text,
                          String language,
                          float rate,
                          float pitch,
                          String frameId,
                          String utteranceId) {
            runOnUiThread(() -> enqueueSpeechFromWeb(
                    text, language, rate, pitch, frameId, utteranceId));
        }

        @JavascriptInterface
        public void speakSegments(String segmentsJson,
                                  String language,
                                  float rate,
                                  float pitch,
                                  String frameId,
                                  String utteranceId) {
            runOnUiThread(() -> enqueueSpeechSegmentsFromWeb(
                    segmentsJson, language, rate, pitch, frameId, utteranceId));
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(ExamActivity.this::stopAllSpeech);
        }

        @JavascriptInterface
        public void notify(String message) {
            runOnUiThread(() -> Toast.makeText(
                    ExamActivity.this,
                    TextUtils.isEmpty(message) ? "Teks soal tidak ditemukan" : message,
                    Toast.LENGTH_LONG).show());
        }
    }

    private void showCustomVideo(View view, WebChromeClient.CustomViewCallback callback) {
        if (customVideoView != null) {
            callback.onCustomViewHidden();
            return;
        }
        customVideoView = view;
        customViewCallback = callback;
        fullscreenVideoContainer.setVisibility(View.VISIBLE);
        fullscreenVideoContainer.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.setVisibility(View.GONE);
        enterImmersiveMode();
    }

    private void hideCustomVideo() {
        if (customVideoView == null) {
            return;
        }
        fullscreenVideoContainer.removeView(customVideoView);
        fullscreenVideoContainer.setVisibility(View.GONE);
        customVideoView = null;
        webView.setVisibility(View.VISIBLE);
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
        enterImmersiveMode();
    }

    private void startExamLockTask() {
        try {
            startLockTask();
            lockTaskStarted = true;
        } catch (Exception ignored) {
            lockTaskStarted = false;
        }
    }

    private void stopExamLockTask() {
        if (!lockTaskStarted) {
            return;
        }
        try {
            stopLockTask();
        } catch (Exception ignored) {
            // Perangkat mungkin sudah keluar dari screen pinning.
        }
        lockTaskStarted = false;
    }

    private void confirmExit() {
        if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) {
            return;
        }
        runOnUiThread(() -> {
            if (exitDialog != null && exitDialog.isShowing()) {
                if (exitDialog.getWindow() != null) {
                    exitDialog.getWindow().getDecorView().requestFocus();
                }
                return;
            }

            exitDialog = new AlertDialog.Builder(this)
                    .setTitle(testMode ? "Tutup tes media?" : "Keluar dari ujian?")
                    .setMessage(testMode
                            ? "Tes kamera dan mikrofon akan dihentikan."
                            : "Pastikan jawaban sudah tersimpan sebelum keluar dari aplikasi ujian.")
                    .setNegativeButton("Batal", (dialog, which) -> dialog.dismiss())
                    .setPositiveButton(testMode ? "Tutup Tes" : "Ya, Keluar",
                            (dialog, which) -> completeExit())
                    .create();

            exitDialog.setCanceledOnTouchOutside(false);
            exitDialog.setCancelable(true);
            exitDialog.setOnShowListener(dialog -> applyImmersiveToDialog(exitDialog));
            exitDialog.setOnDismissListener(dialog -> {
                exitDialog = null;
                if (!isFinishing()) {
                    enterImmersiveMode();
                }
            });
            exitDialog.show();
            applyImmersiveToDialog(exitDialog);
        });
    }

    private void applyImmersiveToDialog(AlertDialog dialog) {
        if (dialog == null || dialog.getWindow() == null) {
            return;
        }
        Window window = dialog.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private void completeExit() {
        if (exitCompleted) {
            return;
        }
        exitCompleted = true;
        handler.removeCallbacks(fullscreenGuardRunnable);
        stopExamLockTask();
        if (exitDialog != null) {
            exitDialog.setOnDismissListener(null);
            exitDialog.dismiss();
            exitDialog = null;
        }

        stopAllSpeech();
        if (testMode) {
            finishApplicationNow();
            return;
        }

        // Beri jeda singkat setelah menghentikan pembacaan soal supaya ucapan
        // keluar tidak ikut terpotong oleh perintah stop sebelumnya.
        handler.postDelayed(this::speakExitMessageAndFinish, 250L);
    }

    private void speakExitMessageAndFinish() {
        if (textToSpeech == null || !ttsReady) {
            finishApplicationNow();
            return;
        }

        exitVoiceInProgress = true;
        exitUtteranceId = "exit_" + System.currentTimeMillis();
        textToSpeech.setLanguage(new Locale("id", "ID"));
        textToSpeech.setSpeechRate(0.95f);
        textToSpeech.setPitch(1.0f);

        int result = textToSpeech.speak(
                "ANDA KELUAR DARI APLIKASI",
                TextToSpeech.QUEUE_FLUSH,
                null,
                exitUtteranceId);

        if (result == TextToSpeech.ERROR) {
            finishApplicationNow();
            return;
        }

        handler.postDelayed(() -> {
            if (exitVoiceInProgress) {
                finishApplicationNow();
            }
        }, EXIT_SPEECH_FALLBACK_MS);
    }

    private void finishApplicationNow() {
        if (!exitVoiceInProgress && !exitCompleted) {
            return;
        }
        exitVoiceInProgress = false;
        exitUtteranceId = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            finishAffinity();
        }
    }

    private void startFullscreenGuard() {
        handler.removeCallbacks(fullscreenGuardRunnable);
        handler.post(fullscreenGuardRunnable);
    }

    private void enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
        enterImmersiveMode();
        startFullscreenGuard();
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(fullscreenGuardRunnable);
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE && filePathCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (exitDialog != null) {
            exitDialog.setOnDismissListener(null);
            exitDialog.dismiss();
            exitDialog = null;
        }
        stopExamLockTask();
        if (pendingWebPermission != null) {
            pendingWebPermission.deny();
            pendingWebPermission = null;
        }
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        stopAllSpeech();
        if (textToSpeech != null) {
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        super.onDestroy();
    }
}
