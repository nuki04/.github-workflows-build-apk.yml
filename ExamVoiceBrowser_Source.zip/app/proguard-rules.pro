# Tidak ada aturan khusus. JavaScript interface dipertahankan secara eksplisit.
-keepclassmembers class id.schoolsafe.examvoice.ExamActivity$JsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
