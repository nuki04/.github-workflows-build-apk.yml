# Penandatanganan APK agar bisa memperbarui aplikasi

APK Android hanya dapat dipasang sebagai pembaruan jika **applicationId** dan sertifikat penandatangan sama, serta `versionCode` tidak lebih kecil.

Repository ini mendukung keystore tetap melalui GitHub Actions Secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Ubah keystore menjadi Base64 sebelum dimasukkan ke secret pertama:

```bash
base64 -w 0 examvoice-release.jks
```

Pada macOS:

```bash
base64 < examvoice-release.jks | tr -d '\n'
```

Setelah empat secret tersedia, gunakan APK `app-release.apk` dari artifact GitHub Actions. Jangan memakai `app-debug.apk` untuk distribusi pembaruan karena runner GitHub dapat menghasilkan identitas debug yang berbeda.

Apabila aplikasi lama ditandatangani dengan keystore yang sudah hilang, aplikasi lama harus dihapus satu kali. Setelah itu instal `app-release.apk`; build release berikutnya dapat memperbarui aplikasi tanpa menghapus data selama keystore yang sama tetap digunakan.
