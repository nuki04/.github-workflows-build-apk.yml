package id.schoolsafe.examvoice;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "exam_voice_prefs";
    private static final String KEY_LAST_URL = "last_url";

    private EditText serverAddress;
    private CheckBox strictModeCheck;
    private CheckBox autoReadCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverAddress = findViewById(R.id.serverAddress);
        strictModeCheck = findViewById(R.id.strictModeCheck);
        autoReadCheck = findViewById(R.id.autoReadCheck);
        Button startExamButton = findViewById(R.id.startExamButton);
        Button scanQrButton = findViewById(R.id.scanQrButton);
        Button testMediaButton = findViewById(R.id.testMediaButton);

        SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        serverAddress.setText(preferences.getString(KEY_LAST_URL, ""));

        startExamButton.setOnClickListener(v -> startExam());
        scanQrButton.setOnClickListener(v -> scanServerQr());
        testMediaButton.setOnClickListener(v -> startMediaTest());
    }

    private void startExam() {
        String normalized = normalizeUrl(serverAddress.getText().toString());
        if (normalized == null) {
            serverAddress.setError("Masukkan alamat server yang benar");
            serverAddress.requestFocus();
            return;
        }

        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putString(KEY_LAST_URL, normalized)
                .apply();

        Intent intent = new Intent(this, ExamActivity.class);
        intent.putExtra(ExamActivity.EXTRA_URL, normalized);
        intent.putExtra(ExamActivity.EXTRA_STRICT_MODE, strictModeCheck.isChecked());
        intent.putExtra(ExamActivity.EXTRA_AUTO_READ, autoReadCheck.isChecked());
        startActivity(intent);
    }

    private void startMediaTest() {
        Intent intent = new Intent(this, ExamActivity.class);
        intent.putExtra(ExamActivity.EXTRA_URL, ExamActivity.MEDIA_TEST_URL);
        intent.putExtra(ExamActivity.EXTRA_STRICT_MODE, false);
        intent.putExtra(ExamActivity.EXTRA_AUTO_READ, false);
        intent.putExtra(ExamActivity.EXTRA_TEST_MODE, true);
        startActivity(intent);
    }

    private void scanServerQr() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .enableAutoZoom()
                .build();
        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> {
                    String value = extractAddress(barcode.getRawValue());
                    if (value == null) {
                        Toast.makeText(this, "QR tidak berisi alamat server yang dikenali", Toast.LENGTH_LONG).show();
                        return;
                    }
                    serverAddress.setText(value);
                    serverAddress.setSelection(value.length());
                })
                .addOnCanceledListener(() -> Toast.makeText(this, "Pemindaian dibatalkan", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(error -> Toast.makeText(this,
                        "Scanner QR belum tersedia: " + safeMessage(error), Toast.LENGTH_LONG).show());
    }

    private String extractAddress(String rawValue) {
        if (TextUtils.isEmpty(rawValue)) {
            return null;
        }
        String raw = rawValue.trim();
        String direct = normalizeUrl(raw);
        if (direct != null) {
            return direct;
        }

        try {
            JSONObject object = new JSONObject(raw);
            String[] keys = {"url", "server", "serverUrl", "alamat", "address"};
            for (String key : keys) {
                String candidate = object.optString(key, "");
                String normalized = normalizeUrl(candidate);
                if (normalized != null) {
                    return normalized;
                }
            }
        } catch (Exception ignored) {
            // QR bukan JSON.
        }

        Matcher matcher = Pattern.compile("https?://[^\\s\\\"']+", Pattern.CASE_INSENSITIVE).matcher(raw);
        if (matcher.find()) {
            return normalizeUrl(matcher.group());
        }
        return null;
    }

    private String normalizeUrl(String value) {
        if (value == null) {
            return null;
        }
        String input = value.trim();
        if (input.isEmpty() || input.contains(" ")) {
            return null;
        }
        if (!input.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*$")) {
            input = "http://" + input;
        }
        try {
            Uri uri = Uri.parse(input);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (scheme == null || host == null || host.trim().isEmpty()) {
                return null;
            }
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
                return null;
            }
            return uri.toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    private String safeMessage(Throwable error) {
        if (error == null || TextUtils.isEmpty(error.getMessage())) {
            return "coba lagi setelah Google Play Services selesai diperbarui";
        }
        return error.getMessage();
    }
}
