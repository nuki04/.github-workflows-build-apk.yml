package id.schoolsafe.examvoice;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.net.http.SslError;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ExamActivity extends Activity implements TextToSpeech.OnInitListener {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_STRICT_MODE = "strict_mode";
    public static final String EXTRA_AUTO_READ = "auto_read";
    public static final String EXTRA_TEST_MODE = "test_mode";
    public static final String MEDIA_TEST_URL = "https://examvoice.local/media-test";

    private static final int REQUEST_WEB_MEDIA = 501;
    private static final int REQUEST_SPEECH_AUDIO = 502;
    private static final int REQUEST_FILE = 503;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout fullscreenVideoContainer;
    private Button menuButton;
    private LinearLayout controlPanel;
    private TextToSpeech textToSpeech;
    private SpeechRecognizer speechRecognizer;
    private PermissionRequest pendingWebPermission;
    private boolean pendingSpeechStart;
    private boolean ttsReady;
    private boolean strictMode;
    private boolean autoRead;
    private boolean testMode;
    private boolean lockTaskStarted;
    private String initialUrl;
    private String lastAutoSpokenUrl;
    private View customVideoView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]> filePathCallback;
    private OnBackInvokedCallback backCallback;

    private final Runnable hideControlsRunnable = () -> controlPanel.setVisibility(View.GONE);

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam);

        initialUrl = getIntent().getStringExtra(EXTRA_URL);
        strictMode = getIntent().getBooleanExtra(EXTRA_STRICT_MODE, true);
        autoRead = getIntent().getBooleanExtra(EXTRA_AUTO_READ, false);
        testMode = getIntent().getBooleanExtra(EXTRA_TEST_MODE, false);
        if (TextUtils.isEmpty(initialUrl)) {
            Toast.makeText(this, "Alamat server tidak tersedia", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (strictMode) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }

        webView = findViewById(R.id.examWebView);
        progressBar = findViewById(R.id.pageProgress);
        fullscreenVideoContainer = findViewById(R.id.fullscreenVideoContainer);
        menuButton = findViewById(R.id.menuButton);
        controlPanel = findViewById(R.id.controlPanel);
        Button readButton = findViewById(R.id.readButton);
        Button stopReadButton = findViewById(R.id.stopReadButton);
        Button dictationButton = findViewById(R.id.dictationButton);
        Button reloadButton = findViewById(R.id.reloadButton);
        Button exitButton = findViewById(R.id.exitButton);

        if (testMode) {
            exitButton.setText("Tutup Tes");
        }

        menuButton.setOnClickListener(v -> toggleControls());
        readButton.setOnClickListener(v -> readSelectedOrPage());
        stopReadButton.setOnClickListener(v -> stopSpeaking());
        dictationButton.setOnClickListener(v -> startSpeechInput());
        reloadButton.setOnClickListener(v -> webView.reload());
        exitButton.setOnClickListener(v -> confirmExit());

        setupBackHandling();
        setupWebView();
        textToSpeech = new TextToSpeech(this, this);
        enterImmersiveMode();
        webView.loadUrl(initialUrl);

        if (strictMode) {
            webView.postDelayed(this::startExamLockTask, 800);
        }
    }

    private void setupBackHandling() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            handleBack();
        }
    }

    private void handleBack() {
        if (customVideoView != null) {
            hideCustomVideo();
            return;
        }
        if (!strictMode && webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        Toast.makeText(this, strictMode
                ? "Tombol kembali dinonaktifkan selama ujian"
                : "Gunakan menu untuk keluar", Toast.LENGTH_SHORT).show();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setUserAgentString(settings.getUserAgentString() + " ExamVoiceBrowser/1.0");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new JsBridge(), "ExamVoiceNative");
        webView.setWebViewClient(new ExamWebViewClient());
        webView.setWebChromeClient(new ExamWebChromeClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (strictMode) {
                Toast.makeText(this, "Unduhan diblokir dalam mode ujian ketat", Toast.LENGTH_LONG).show();
            } else {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception error) {
                    Toast.makeText(this, "Tidak ada aplikasi untuk membuka unduhan", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private class ExamWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(5);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progressBar.setProgress(100);
            handler.postDelayed(() -> progressBar.setVisibility(View.GONE), 250);
            injectVoiceBridgeHelper();
            if (autoRead && !testMode && !TextUtils.equals(lastAutoSpokenUrl, url)) {
                lastAutoSpokenUrl = url;
                handler.postDelayed(ExamActivity.this::readSelectedOrPage, 1000);
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleNavigation(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleNavigation(Uri.parse(url));
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return interceptLocalTest(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            return interceptLocalTest(Uri.parse(url));
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                String message = error == null ? "Gagal membuka server" : error.getDescription().toString();
                Toast.makeText(ExamActivity.this, message, Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            Toast.makeText(ExamActivity.this,
                    "Sertifikat HTTPS server tidak valid. Gunakan sertifikat yang sah atau alamat HTTP lokal.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private class ExamWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            progressBar.setProgress(newProgress);
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> handleWebPermissionRequest(request));
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pendingWebPermission == request) {
                pendingWebPermission = null;
            }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            showCustomVideo(view, callback);
        }

        @Override
        public void onHideCustomView() {
            hideCustomVideo();
        }

        @Override
        public boolean onShowFileChooser(WebView webView,
                                         ValueCallback<Uri[]> filePathCallback,
                                         FileChooserParams fileChooserParams) {
            if (strictMode) {
                Toast.makeText(ExamActivity.this,
                        "Pemilih file dinonaktifkan dalam mode ujian ketat", Toast.LENGTH_LONG).show();
                return false;
            }
            if (ExamActivity.this.filePathCallback != null) {
                ExamActivity.this.filePathCallback.onReceiveValue(null);
            }
            ExamActivity.this.filePathCallback = filePathCallback;
            try {
                Intent chooser = fileChooserParams.createIntent();
                startActivityForResult(chooser, REQUEST_FILE);
                return true;
            } catch (Exception error) {
                ExamActivity.this.filePathCallback = null;
                Toast.makeText(ExamActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    private boolean handleNavigation(Uri uri) {
        if (uri == null || uri.getScheme() == null) {
            return true;
        }
        String scheme = uri.getScheme().toLowerCase(Locale.ROOT);
        if ("http".equals(scheme) || "https".equals(scheme)) {
            return false;
        }
        Toast.makeText(this, "Tautan eksternal diblokir: " + scheme, Toast.LENGTH_SHORT).show();
        return true;
    }

    private WebResourceResponse interceptLocalTest(Uri uri) {
        if (uri == null
                || !"examvoice.local".equalsIgnoreCase(uri.getHost())
                || !"/media-test".equals(uri.getPath())) {
            return null;
        }
        try {
            InputStream input = getAssets().open("media_test.html");
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            headers.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("text/html", "UTF-8", 200, "OK", headers, input);
        } catch (IOException error) {
            return null;
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) {
            return;
        }
        if (pendingWebPermission != null && pendingWebPermission != request) {
            pendingWebPermission.deny();
        }
        pendingWebPermission = request;

        List<String> missing = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.RECORD_AUDIO);
            }
        }

        if (missing.isEmpty()) {
            grantPendingWebPermission();
        } else {
            requestPermissions(missing.toArray(new String[0]), REQUEST_WEB_MEDIA);
        }
    }

    private void grantPendingWebPermission() {
        PermissionRequest request = pendingWebPermission;
        pendingWebPermission = null;
        if (request == null) {
            return;
        }
        List<String> allowed = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                allowed.add(resource);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                allowed.add(resource);
            }
        }
        if (allowed.isEmpty()) {
            request.deny();
        } else {
            request.grant(allowed.toArray(new String[0]));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WEB_MEDIA) {
            grantPendingWebPermission();
        } else if (requestCode == REQUEST_SPEECH_AUDIO) {
            boolean granted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            if (pendingSpeechStart && granted) {
                pendingSpeechStart = false;
                beginSpeechRecognition();
            } else {
                pendingSpeechStart = false;
                Toast.makeText(this, "Izin mikrofon diperlukan untuk dikte", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void injectVoiceBridgeHelper() {
        String script = "(function(){"
                + "window.ExamVoice=window.ExamVoice||{};"
                + "window.ExamVoice.speak=function(t){if(window.ExamVoiceNative){ExamVoiceNative.speak(String(t||''));}};"
                + "window.ExamVoice.stop=function(){if(window.ExamVoiceNative){ExamVoiceNative.stop();}};"
                + "})();";
        webView.evaluateJavascript(script, null);
    }

    private void readSelectedOrPage() {
        if (!ttsReady) {
            Toast.makeText(this, "Mesin suara sedang disiapkan", Toast.LENGTH_SHORT).show();
            return;
        }
        String script = "(function(){"
                + "var selected=(window.getSelection?window.getSelection().toString():'').trim();"
                + "var root=document.querySelector('main,[role=main],.question,.soal,#question,#soal')||document.body;"
                + "var text=selected;"
                + "if(!text&&root){var clone=root.cloneNode(true);"
                + "var nodes=clone.querySelectorAll('script,style,noscript,nav,header,footer,button,input,textarea,select,video,audio,canvas,svg');"
                + "for(var i=0;i<nodes.length;i++){if(nodes[i].parentNode){nodes[i].parentNode.removeChild(nodes[i]);}}"
                + "text=(clone.innerText||clone.textContent||'');}"
                + "text=String(text||'').replace(/\\s+/g,' ').trim().slice(0,15000);"
                + "return JSON.stringify({text:text,lang:(document.documentElement.lang||'')});"
                + "})()";
        webView.evaluateJavascript(script, value -> {
            try {
                String payload = decodeJavascriptString(value);
                JSONObject data = new JSONObject(payload);
                String text = data.optString("text", "").trim();
                String language = data.optString("lang", "");
                if (text.length() < 2) {
                    Toast.makeText(this, "Tidak ada teks yang dapat dibacakan", Toast.LENGTH_SHORT).show();
                    return;
                }
                speakText(text, language);
            } catch (Exception error) {
                Toast.makeText(this, "Teks halaman tidak dapat dibaca", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String decodeJavascriptString(String value) throws Exception {
        if (value == null || "null".equals(value)) {
            return "";
        }
        Object decoded = new JSONTokener(value).nextValue();
        return decoded == null ? "" : decoded.toString();
    }

    private void speakText(String rawText, String pageLanguage) {
        if (!ttsReady || textToSpeech == null) {
            return;
        }
        String text = normalizeForSpeech(rawText);
        Locale locale = chooseSpeechLocale(pageLanguage, text);
        int languageResult = textToSpeech.setLanguage(locale);
        if (languageResult == TextToSpeech.LANG_MISSING_DATA
                || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            textToSpeech.setLanguage(new Locale("id", "ID"));
        }
        textToSpeech.setSpeechRate(0.94f);
        textToSpeech.stop();

        List<String> chunks = splitText(text, 3000);
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        for (int i = 0; i < chunks.size(); i++) {
            textToSpeech.speak(chunks.get(i), TextToSpeech.QUEUE_ADD, params, "examvoice-" + i);
        }
        Toast.makeText(this, "Membacakan teks halaman", Toast.LENGTH_SHORT).show();
    }

    private Locale chooseSpeechLocale(String pageLanguage, String text) {
        String lang = pageLanguage == null ? "" : pageLanguage.toLowerCase(Locale.ROOT);
        if (lang.startsWith("ar") || containsArabic(text)) {
            return new Locale("ar");
        }
        if (lang.startsWith("en")) {
            return Locale.US;
        }
        return new Locale("id", "ID");
    }

    private boolean containsArabic(String text) {
        int arabic = 0;
        int letters = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetter(c)) {
                letters++;
                if ((c >= '\u0600' && c <= '\u06FF') || (c >= '\u0750' && c <= '\u077F')) {
                    arabic++;
                }
            }
        }
        return letters > 0 && arabic * 5 > letters;
    }

    private String normalizeForSpeech(String text) {
        return text
                .replace("×", " kali ")
                .replace("÷", " dibagi ")
                .replace("−", " minus ")
                .replace("+", " tambah ")
                .replace("=", " sama dengan ")
                .replace("≤", " kurang dari atau sama dengan ")
                .replace("≥", " lebih dari atau sama dengan ")
                .replace("√", " akar ")
                .replace("%", " persen ")
                .replace("°", " derajat ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private List<String> splitText(String text, int maximumLength) {
        List<String> chunks = new ArrayList<>();
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + maximumLength, text.length());
            if (end < text.length()) {
                int sentence = Math.max(text.lastIndexOf('.', end),
                        Math.max(text.lastIndexOf('?', end), text.lastIndexOf('!', end)));
                int space = text.lastIndexOf(' ', end);
                if (sentence > start + maximumLength / 2) {
                    end = sentence + 1;
                } else if (space > start + maximumLength / 2) {
                    end = space;
                }
            }
            String chunk = text.substring(start, end).trim();
            if (!chunk.isEmpty()) {
                chunks.add(chunk);
            }
            start = end;
        }
        return chunks;
    }

    private void stopSpeaking() {
        if (textToSpeech != null) {
            textToSpeech.stop();
        }
    }

    private void startSpeechInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingSpeechStart = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_SPEECH_AUDIO);
            return;
        }
        beginSpeechRecognition();
    }

    private void beginSpeechRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Layanan pengenal suara tidak tersedia di perangkat ini", Toast.LENGTH_LONG).show();
            return;
        }
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new ExamRecognitionListener());
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan jawaban");
        try {
            speechRecognizer.startListening(intent);
        } catch (Exception error) {
            Toast.makeText(this, "Dikte suara gagal dimulai", Toast.LENGTH_LONG).show();
        }
    }

    private class ExamRecognitionListener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle params) {
            Toast.makeText(ExamActivity.this, "Silakan bicara…", Toast.LENGTH_SHORT).show();
        }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onError(int error) {
            Toast.makeText(ExamActivity.this, speechErrorMessage(error), Toast.LENGTH_SHORT).show();
        }
        @Override public void onResults(Bundle results) {
            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (matches != null && !matches.isEmpty()) {
                insertDictation(matches.get(0));
            }
        }
        @Override public void onPartialResults(Bundle partialResults) { }
        @Override public void onEvent(int eventType, Bundle params) { }
    }

    private String speechErrorMessage(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_AUDIO: return "Mikrofon tidak dapat digunakan";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Izin mikrofon belum diberikan";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Jaringan pengenal suara bermasalah";
            case SpeechRecognizer.ERROR_NO_MATCH: return "Ucapan belum dikenali, silakan ulangi";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Pengenal suara sedang sibuk";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "Tidak ada suara yang terdeteksi";
            default: return "Dikte suara berhenti";
        }
    }

    private void insertDictation(String text) {
        if (TextUtils.isEmpty(text)) {
            return;
        }
        String quoted = JSONObject.quote(text);
        String script = "(function(t){"
                + "var e=document.activeElement;"
                + "if(e&&(e.tagName==='INPUT'||e.tagName==='TEXTAREA')){"
                + "var s=typeof e.selectionStart==='number'?e.selectionStart:e.value.length;"
                + "var n=typeof e.selectionEnd==='number'?e.selectionEnd:e.value.length;"
                + "e.value=e.value.slice(0,s)+t+e.value.slice(n);"
                + "e.dispatchEvent(new Event('input',{bubbles:true}));"
                + "e.dispatchEvent(new Event('change',{bubbles:true}));"
                + "}else if(e&&e.isContentEditable){document.execCommand('insertText',false,t);"
                + "}else{window.dispatchEvent(new CustomEvent('examvoice-dictation',{detail:t}));}"
                + "})(" + quoted + ");";
        webView.evaluateJavascript(script, null);
        Toast.makeText(this, "Dikte dimasukkan: " + text, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
            ttsReady = true;
            textToSpeech.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            textToSpeech.setLanguage(new Locale("id", "ID"));
        } else {
            Toast.makeText(this, "Mesin Text-to-Speech tidak tersedia", Toast.LENGTH_LONG).show();
        }
    }

    public class JsBridge {
        @JavascriptInterface
        public void speak(String text) {
            runOnUiThread(() -> {
                if (!TextUtils.isEmpty(text)) {
                    speakText(text, "id-ID");
                }
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(ExamActivity.this::stopSpeaking);
        }
    }

    private void toggleControls() {
        boolean show = controlPanel.getVisibility() != View.VISIBLE;
        controlPanel.setVisibility(show ? View.VISIBLE : View.GONE);
        handler.removeCallbacks(hideControlsRunnable);
        if (show) {
            handler.postDelayed(hideControlsRunnable, 9000);
        }
    }

    private void showCustomVideo(View view, WebChromeClient.CustomViewCallback callback) {
        if (customVideoView != null) {
            callback.onCustomViewHidden();
            return;
        }
        customVideoView = view;
        customViewCallback = callback;
        fullscreenVideoContainer.setVisibility(View.VISIBLE);
        fullscreenVideoContainer.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.setVisibility(View.GONE);
        menuButton.setVisibility(View.GONE);
        controlPanel.setVisibility(View.GONE);
        enterImmersiveMode();
    }

    private void hideCustomVideo() {
        if (customVideoView == null) {
            return;
        }
        fullscreenVideoContainer.removeView(customVideoView);
        fullscreenVideoContainer.setVisibility(View.GONE);
        customVideoView = null;
        webView.setVisibility(View.VISIBLE);
        menuButton.setVisibility(View.VISIBLE);
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
        enterImmersiveMode();
    }

    private void startExamLockTask() {
        try {
            startLockTask();
            lockTaskStarted = true;
        } catch (Exception ignored) {
            lockTaskStarted = false;
        }
    }

    private void stopExamLockTask() {
        if (!lockTaskStarted) {
            return;
        }
        try {
            stopLockTask();
        } catch (Exception ignored) {
            // Perangkat mungkin sudah keluar dari screen pinning.
        }
        lockTaskStarted = false;
    }

    private void confirmExit() {
        new AlertDialog.Builder(this)
                .setTitle(testMode ? "Tutup tes media?" : "Keluar dari ujian?")
                .setMessage(testMode
                        ? "Tes kamera dan mikrofon akan dihentikan."
                        : "Pastikan jawaban sudah tersimpan sebelum keluar.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Keluar", (dialog, which) -> finishExam())
                .show();
    }

    private void finishExam() {
        stopSpeaking();
        stopExamLockTask();
        finish();
    }

    private void enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
        enterImmersiveMode();
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE && filePathCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopExamLockTask();
        if (pendingWebPermission != null) {
            pendingWebPermission.deny();
            pendingWebPermission = null;
        }
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (speechRecognizer != null) {
            speechRecognizer.cancel();
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        super.onDestroy();
    }
}
