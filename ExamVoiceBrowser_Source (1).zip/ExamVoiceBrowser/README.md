# Exam Voice Browser

Aplikasi Android exam browser baru yang dibuat dari nol. Proyek ini tidak memakai kode, nama paket, aset, tanda tangan, atau identitas aplikasi APK referensi.

## Fitur

- WebView layar penuh untuk membuka server ujian.
- Mendukung alamat server HTTPS dan HTTP lokal/LAN.
- Video live dan audio WebRTC melalui `getUserMedia`.
- Pemutaran audio/video otomatis setelah media diizinkan.
- Tes kamera depan/belakang dan meter suara mikrofon.
- Text-to-Speech untuk membacakan teks terpilih atau isi halaman.
- Normalisasi simbol matematika dasar saat dibacakan.
- Dukungan bahasa Indonesia, Inggris berdasarkan atribut `lang`, dan deteksi teks Arab.
- Dikte suara ke input/textarea yang sedang aktif.
- Scan QR alamat server memakai Google Code Scanner.
- Mode ujian ketat: immersive fullscreen, `FLAG_SECURE`, tombol Back diblokir, dan Android screen pinning/lock task.
- Video HTML5 fullscreen.
- Tidak ada SDK iklan/AdMob.

## Membuka dan membangun

1. Buka folder proyek di Android Studio.
2. Pastikan **Android SDK Platform 36**, **Build Tools 36.x**, dan **JDK 17** terpasang.
3. Tunggu Gradle Sync selesai. Koneksi internet dibutuhkan pada sinkronisasi pertama untuk mengambil Google Code Scanner.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Konfigurasi proyek:

- Android Gradle Plugin: 9.2.0
- compileSdk/targetSdk: 36
- minSdk: 23 (Android 6.0)
- Java: 17

## Cara memakai

1. Isi URL server, misalnya `http://192.168.1.10:8080`.
2. Aktifkan mode ujian ketat bila diperlukan.
3. Tekan **Mulai Ujian**.
4. Saat situs meminta kamera/mikrofon, izinkan melalui dialog Android.
5. Tekan tombol `⋮` di kanan atas untuk membuka:
   - Baca Soal
   - Hentikan Suara
   - Dikte Jawaban
   - Muat Ulang
   - Keluar

## Integrasi situs ujian

Video live dan audio standar:

```javascript
const stream = await navigator.mediaDevices.getUserMedia({
  video: true,
  audio: true
});
document.querySelector('video').srcObject = stream;
```

Membacakan teks tertentu dari halaman:

```javascript
window.ExamVoice.speak('Teks soal yang ingin dibacakan');
window.ExamVoice.stop();
```

Menerima hasil dikte ketika tidak ada input yang sedang fokus:

```javascript
window.addEventListener('examvoice-dictation', event => {
  console.log(event.detail);
});
```

## Catatan penting

- Untuk kamera/mikrofon di halaman web internet, gunakan **HTTPS**. HTTP tetap didukung untuk halaman ujian lokal, tetapi Chromium dapat membatasi `getUserMedia` pada origin yang tidak aman.
- Android biasa tidak dapat memblokir tombol Home/Recent secara absolut tanpa perangkat dikelola sebagai **Device Owner/kiosk**. Mode ini memakai screen pinning/lock task yang tersedia untuk aplikasi biasa.
- Dikte suara dapat memerlukan layanan pengenal suara Google/OEM dan koneksi internet, tergantung perangkat.
- Google Code Scanner memerlukan Google Play Services. Perangkat tanpa Google Play Services masih dapat menjalankan browser ujian, tetapi tombol scan QR mungkin tidak berfungsi.
