# Integrasi Server Ujian

## 1. Video live dengan suara

Gunakan HTTPS dan elemen video `playsinline`:

```html
<video id="live" autoplay playsinline></video>
<script>
async function startLive() {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: 'user' },
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true
    }
  });
  document.getElementById('live').srcObject = stream;
}
</script>
```

## 2. Pembaca soal native

```javascript
function bacaSoal() {
  const teks = document.querySelector('.soal').innerText;
  if (window.ExamVoice) window.ExamVoice.speak(teks);
}
```

Tambahkan atribut bahasa agar pengucapan menyesuaikan:

```html
<html lang="id">
<!-- atau lang="en", lang="ar" -->
```

## 3. Dikte jawaban

Saat tombol Dikte Jawaban ditekan, hasil otomatis dimasukkan ke elemen `input`, `textarea`, atau `contenteditable` yang fokus. Untuk komponen editor khusus:

```javascript
window.addEventListener('examvoice-dictation', event => {
  editor.setValue(event.detail);
});
```

## 4. Kebijakan izin

Aplikasi hanya meneruskan izin WebView untuk sumber:

- `android.webkit.resource.VIDEO_CAPTURE`
- `android.webkit.resource.AUDIO_CAPTURE`

Izin Android `CAMERA` dan `RECORD_AUDIO` tetap harus disetujui pengguna.
